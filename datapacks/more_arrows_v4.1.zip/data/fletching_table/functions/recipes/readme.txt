create your own arrow!

copy any of the folder in this folder, 

change a name as you like,

give an special id for it,

the add all functions in your copyed folder to the data/fletchig_table/tags/fucntions respectively.
